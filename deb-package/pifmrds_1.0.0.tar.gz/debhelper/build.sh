#!/bin/sh
sudo dpkg-buildpackage